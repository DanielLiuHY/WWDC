//
//  main.m
//  primeNumber
//
//  Created by Liuhengyu on 16/5/20.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#import <Foundation/Foundation.h>



int isPrimeNumber(int a) {
    int tmp = 0;
        for(int j=2;j<sqrt(a);j++) {
            if(0 == a%j){
                tmp = 1;
                break;
            }
    }
    return  tmp;
}


int main(int argc, const char * argv[]) {
    @autoreleasepool {
        for (int i=2;i<1000000;i++){
            if (isPrimeNumber(i) == 0){
                printf("%d\n",i);
            }
            
        }
    }
    return 0;
}
