//
//  Array.h
//  DynamicArray
//
//  Created by Liuhengyu on 16/5/20.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#ifndef Array_h
#define Array_h

#include <stdio.h>
#include "Object.h"
typedef Object* AnyPointer;

typedef struct Array_{
    int retainCount_;
    int length_;
    int capacity_;
    AnyPointer *values_;
}Array;

Array * arrayCreate();
int ArrayGetLength(Array *arr);
void ArrayAdd(Array *arr, AnyPointer value);
AnyPointer ArrayGet(Array *arr, int index);
void ArrayDestory(Array *arr);
void ArrayRemoveAt(Array *arr, int index);
void ArrayInsertInfoAt(Array *arr, int index, AnyPointer value);
#endif /* Array_h */
