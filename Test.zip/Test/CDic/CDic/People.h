//
//  People.h
//  CDic
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#ifndef People_h
#define People_h

#include <stdio.h>
#include "Object.h"

typedef struct people_{
    int retainCount_;
    char* name_;
    int age_;
}people;

people* peopel_new(char* name,int age);
char* peopleGetName(people *p);
int peopleGetAge(people *p);

#endif /* People_h */
