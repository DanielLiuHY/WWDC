//
//  CDic.h
//  CDic
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#ifndef CDic_h
#define CDic_h

#include <stdio.h>
#include "Object.h"
#include "Array.h"
#include "KeyValuePair.h"
#include <stdlib.h>
#include "People.h"
Array *createNewMap();
void mapDestory(Array* map);
//void addNewKeyTo(Array* map, keyValuePair keyValue);
void hash_map_put(Array* map, char* key, AnyPointer *value);
void hash_map_get(Array *map, char* key);
void hash_map_remove(Array *map, char* key);



#endif /* CDic_h */
