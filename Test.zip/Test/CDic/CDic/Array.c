//
//  Array.c
//  DynamicArray
//
//  Created by Liuhengyu on 16/5/20.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#include "Array.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "Info.h"
static AnyPointer * allocMemoryByCapacity(Array *arr){
    return malloc(sizeof(AnyPointer) * arr->capacity_);
    OBJECT_RETAIN(arr);
}

Array * arrayCreate(){
    Array *arr = malloc(sizeof(Array));
    arr->length_ = 0;
    arr->capacity_ = 1;
    arr->values_ = malloc(sizeof(int));
    OBJECT_RETAIN(arr);
    return arr;
}
int ArrayGetLength(Array *arr){
    return arr->length_;
}
void ArrayAdd(Array *arr, AnyPointer value){
    if(arr->length_>= arr->capacity_){
        arr->capacity_*=2;
        AnyPointer *oldValues = arr->values_;
        arr->values_ = allocMemoryByCapacity(arr);
        memcpy(arr->values_, oldValues, arr->length_ * sizeof(AnyPointer));
        free(oldValues);
    }
    arr->values_[arr->length_] = value;
    arr->length_++;
    OBJECT_RETAIN(value);
}
AnyPointer ArrayGet(Array *arr, int index){
    assert(index>=0 && index<arr->length_);
    return arr->values_[index];
}
void ArrayDestory(Array *arr){

    OBJECT_RELEASE(arr->values_);
    OBJECT_RELEASE(arr);
    if(OBJECT_RETAIN_COUNT(arr) ==0 ){
        printf("数组已经销毁\n");
    }
}
void ArrayRemoveAt(Array *arr, int index)  {
    assert(index>=0 && index < arr->length_);
    OBJECT_RELEASE(ArrayGet(arr,index));
    arr->length_--;
    for (int i = index; i<arr->length_;i++){
        arr->values_[i] = arr->values_[i+1];
    }
}
void ArrayInsertInfoAt(Array *arr, int index, AnyPointer value){
   assert(index>=0 && index < arr->length_);
   arr->length_++;
    if(arr->length_>= arr->capacity_){
        arr->capacity_*=2;
        AnyPointer *oldValues = arr->values_;
        arr->values_ = allocMemoryByCapacity(arr);
        memcpy(arr->values_, oldValues, arr->length_ * sizeof(AnyPointer));
        free(oldValues);
    }
    for (int i = index; i<arr->length_;i++){
        arr->values_[i+1] = arr->values_[i];
    }
    arr->values_[index] = value;
    OBJECT_RETAIN(value);
}