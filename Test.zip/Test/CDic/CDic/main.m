//
//  main.m
//  CDic
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "People.h"
#include "KeyValuePair.h"
#include "CDic.h"
#include "Array.h"
#include "Object.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
  people* p = peopel_new("小明", 21);
        Array* map = createNewMap();
        hash_map_put(map, "me", (Object**) p);
        OBJECT_RELEASE(p);
        hash_map_get(map, "me");
        hash_map_remove(map, "me");
        mapDestory(map);
    }
    return 0;
}
