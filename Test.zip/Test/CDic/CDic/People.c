//
//  People.c
//  CDic
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#include "People.h"
# include <stdlib.h>
#include "Object.h"

people* peopel_new(char* name,int age){
    people* newPeo = malloc(sizeof(people));
    newPeo->age_ = age;
    newPeo->name_ = name;
    OBJECT_RETAIN(newPeo);
    return newPeo;
}
char* peopleGetName(people *p){
    return p->name_;
}
int peopleGetAge(people *p){
    return p->age_;
}