//
//  CDic.c
//  CDic
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#include "CDic.h"


Array *createNewMap(){
    Array* newMap = arrayCreate();
    return newMap;
}

void mapDestory(Array* map){
    OBJECT_RELEASE(map);
    if(OBJECT_RETAIN_COUNT(map) == 0){
        printf("Map已经被销毁\n");
    }
}

void hash_map_put(Array* map, char* key, AnyPointer *value){
    keyValuePair* tmp = malloc(sizeof(keyValuePair));
    tmp->key_ = key;
    tmp->value_ = value;
    ArrayAdd(map, (Object*)tmp);
    OBJECT_RETAIN(value);
    OBJECT_RETAIN(tmp);
    //OBJECT_RELEASE(tmp);
}


void hash_map_get(Array *map, char* key){
    for (int i=0;i<ArrayGetLength(map);i++){
        if (keyValueGetkey((keyValuePair*) ArrayGet(map, i)) == key){
            printf("find%s!,name:%s,age:%d\n",key,peopleGetName((people*)keyValueGetValue((keyValuePair*)ArrayGet(map, i))),peopleGetAge((people*)keyValueGetValue((keyValuePair*)ArrayGet(map, i))));
        }
        else{
            printf("do not have that key\n");
        }
    }
}
void hash_map_remove(Array *map, char* key){
    
    for(int i = 0; i<ArrayGetLength(map);i++){
        if(keyValueGetkey((keyValuePair*)ArrayGet(map, i)) == key){
            keyValueDestory((keyValuePair*)ArrayGet(map, i));
            ArrayRemoveAt(map, i);
            printf("the key-value pair has been removed\n");
        }
        else{
            printf("do not find that key\n");
        }
    }
}