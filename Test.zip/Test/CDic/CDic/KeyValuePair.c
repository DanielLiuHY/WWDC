//
//  KeyValuePair.c
//  CDic
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#include "KeyValuePair.h"
#include <stdlib.h>
#include "Object.h"

keyValuePair *createNewKeyValue(char* key, AnyPointer* value){
 keyValuePair *pair = malloc(sizeof(keyValuePair));
    pair->key_ = key;
    pair->value_ = value;
    OBJECT_RETAIN(pair);
    return pair;
}

void keyValueDestory(keyValuePair *keyValuePair){
    OBJECT_RELEASE(keyValuePair);
    if(OBJECT_RETAIN_COUNT(keyValuePair) == 0){
        printf("键值对已经被销毁\n");
    }
}
char * keyValueGetkey(keyValuePair* keyValuePair){
    return (char*)keyValuePair->key_;
}
AnyPointer* keyValueGetValue(keyValuePair* keyValuePair){
    return keyValuePair->value_;
}