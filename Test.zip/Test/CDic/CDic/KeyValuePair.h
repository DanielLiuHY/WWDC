//
//  KeyValuePair.h
//  CDic
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#ifndef KeyValuePair_h
#define KeyValuePair_h

#include <stdio.h>
#include "Object.h"
#include "Array.h"
typedef struct keyValuePair_{
    int retainCount_;
    char* key_;
    AnyPointer* value_;
}keyValuePair;

keyValuePair *createNewKeyValue(char* key, AnyPointer* value);
void keyValueDestory(keyValuePair *keyValuePair);
char * keyValueGetkey(keyValuePair* keyValuePair);
AnyPointer* keyValueGetValue(keyValuePair* keyValuePair);
#endif /* KeyValuePair_h */
