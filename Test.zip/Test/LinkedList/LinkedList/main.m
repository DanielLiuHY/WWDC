//
//  main.m
//  LinkedList
//
//  Created by Liuhengyu on 16/5/20.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef struct Node_{
    int value;
    struct Node_ *next;
} Node;

Node *createNode(int value,Node *next){
    Node *node = malloc(sizeof(Node));
    node->value = value;
    node->next = next;
    return node;
}


void printList(Node *firstNode){
    for(Node *node = firstNode; node!= NULL; node = node->next){
        printf("%d\n",node->value);

    }
}

void reverseSinglyLinkedList(Node *firstNode){
    if (firstNode == NULL)
    {
        printf("The list is empty");
    }
    else{
        Node *tmp1 = malloc(sizeof(Node));
        Node *tmp = malloc(sizeof(Node));
        Node *p = malloc(sizeof(Node));
        tmp1->next = firstNode;
        while (firstNode->next != NULL) {
        tmp = firstNode->next;
        p = tmp->next;
        firstNode->next = p;
        tmp->next = tmp1->next;
        tmp1->next = tmp;
       }
        printf("reversed:\n");
        firstNode = tmp1->next;
        printList(firstNode);
        free(tmp1);
        free (p);
        free(tmp);
    }
}
void destoryList(Node *firstNode){
    Node *node = firstNode;
    Node *tmp;
    while (node != NULL){
        tmp = node;
        node = node->next;
        free(tmp);
    }
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Node *current = createNode(0,NULL);
        Node *first = current;
        
        for(int i=1;i<10;i++){
            Node *nextNode = createNode(i,NULL);
            current->next = nextNode;
            current = current->next;

        }
        printList(first);
        reverseSinglyLinkedList(first);
        destoryList(first);
    }
    return 0;
}
