//
//  Info.c
//  DynamicArray
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#include "Info.h"
#include <stdlib.h>
#include "Object.h"
Info *infoAddIn(char* name, int age){
    Info* information = malloc(sizeof(Info));
    information->name = name;
    information->age = age;
    OBJECT_RETAIN(information);
    return information;
}
char* infoGetName(Info* information){
    return information->name;
}
int infoGetAge(Info* information){
    return information->age;
    
}
void infoDestory(Info* information){
    OBJECT_RELEASE(information);
}