//
//  Integer.c
//  DynamicArray
//
//  Created by Liuhengyu on 16/5/20.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#include "Integer.h"
#include <stdlib.h>
#include "Object.h"
Integer* IntegerNew(int32_t value){
    Integer *ins = malloc(sizeof(Integer));
    ObjectRetain((Object*)ins);
    ins->value_ = value;
    return ins;
}
int32_t IntegerGet(Integer *ins){
    return ins->value_;
}