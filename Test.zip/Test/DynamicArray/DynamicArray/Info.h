//
//  Info.h
//  DynamicArray
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#ifndef Info_h
#define Info_h

#include <stdio.h>
#include "Array.h"
typedef struct Info_{
    int retainCount_;
    int position;
    char* name;
    int age;
}Info;
Info *infoAddIn(char* name, int age);
char* infoGetName(Info* information);
int infoGetAge(Info* information);
void infoDestory(Info* information);
#endif /* Info_h */
