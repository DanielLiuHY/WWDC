//
//  main.m
//  DynamicArray
//
//  Created by Liuhengyu on 16/5/20.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Array.h"
#include "Object.h"
#include "Integer.h"
#include "Info.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {

        Array *arr = arrayCreate();
        
        Info *information1 = infoAddIn("小明", 20);
        ArrayAdd(arr,(Object*)information1);
        infoDestory(information1);
    
        Info *information2 = infoAddIn("大明", 21);
        ArrayAdd(arr,(Object*)information2);
        infoDestory(information2);
        
        Info *information3 = infoAddIn("小李", 22);
        ArrayAdd(arr,(Object*)information3);
        infoDestory(information3);
        
        Info *information4 = infoAddIn("小张", 23);
        ArrayAdd(arr,(Object*)information4);
        infoDestory(information4);
        
        Info *information5 = infoAddIn("小马", 24);
        ArrayAdd(arr,(Object*)information5);
        infoDestory(information5);
        
        Info *information6 = infoAddIn("小陈", 25);
        ArrayAdd(arr,(Object*)information6);
        infoDestory(information6);
        
        Info *information7 = infoAddIn("小蔡", 26);
        ArrayAdd(arr,(Object*)information7);
        infoDestory(information7);
        
        Info *information8 = infoAddIn("小王", 27);
        ArrayAdd(arr,(Object*)information8);
        infoDestory(information8);
        
        printf("全部打印输出\n");
        for (int i = 0; i<ArrayGetLength(arr);i++){
            printf("位置:%d,名字:%s,年龄:%d\n",i+1,infoGetName((Info*)ArrayGet(arr, i)),infoGetAge((Info*)ArrayGet(arr,i)));
        }
        ArrayRemoveAt(arr, 2);
        printf("把小李删掉输出\n");
        for (int i = 0; i<ArrayGetLength(arr);i++){
            printf("位置:%d,名字:%s,年龄:%d\n",i+1,infoGetName((Info*)ArrayGet(arr, i)),infoGetAge((Info*)ArrayGet(arr,i)));
        }
        Info *information9 = infoAddIn("老王", 50);
        ArrayInsertInfoAt(arr, 5, (Object*)information9);
        infoDestory(information9);
        
        printf("欢迎老王加入\n");
        for (int i = 0; i<ArrayGetLength(arr);i++){
            printf("位置:%d,名字:%s,年龄:%d\n",i+1,infoGetName((Info*)ArrayGet(arr, i)),infoGetAge((Info*)ArrayGet(arr,i)));
        }
        printf("第二个人是谁\n");
        printf("他是:%s,今年:%d\n",infoGetName((Info*)ArrayGet(arr, 1)),infoGetAge((Info*)ArrayGet(arr,1)));
        printf("销毁数组\n");
       
        ArrayDestory(arr);
         //printf("%d\n",OBJECT_RETAIN_COUNT(information1));
               }
    }