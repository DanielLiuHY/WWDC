//
//  main.m
//  MRCARC
//
//  Created by Liuhengyu on 16/5/21.
//  Copyright © 2016年 Liuhengyu. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}
