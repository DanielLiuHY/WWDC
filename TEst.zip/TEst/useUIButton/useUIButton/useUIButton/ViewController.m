//
//  ViewController.m
//  useUIButton
//
//  Created by Devin Liu on 16/6/13.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIButton *dis;
@property (weak, nonatomic) IBOutlet UIButton *sel;
@property (weak, nonatomic) IBOutlet UIButton *nor;
@property (weak, nonatomic) IBOutlet UIButton *btn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _btn.frame = CGRectMake(0, 0, 200, 200);
    
    _btn.backgroundColor = [UIColor redColor];
    [_btn setImage:[UIImage imageNamed:@"1.png"] forState:UIControlStateNormal];
    [_btn setImage:[UIImage imageNamed:@"2.png"] forState:UIControlStateHighlighted];
    [_btn setImage:[UIImage imageNamed:@"3.png"] forState:UIControlStateDisabled];
    [_btn setImage:[UIImage imageNamed:@"4.png"] forState:UIControlStateSelected];
    [self.view addSubview:_btn];
    [self.dis addTarget:self action:@selector(dis1) forControlEvents:UIControlEventTouchUpInside];
    [self.sel addTarget:self action:@selector(sel1) forControlEvents:UIControlEventTouchUpInside];
    [self.nor addTarget:self action:@selector(nor1) forControlEvents:UIControlEventTouchUpInside];
    
}
-(void)dis1{
    _btn.selected = NO;
    [_btn setEnabled:NO];
 
}
-(void)sel1{
    [_btn setEnabled:YES];
    _btn.selected = YES;
    
}
-(void)nor1{
    [_btn setEnabled:YES];
    _btn.selected = NO;
}



@end

