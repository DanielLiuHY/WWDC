//
//  AppDelegate.h
//  useUIButton
//
//  Created by Devin Liu on 16/6/13.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

