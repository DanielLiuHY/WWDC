//
//  main.swift
//  Test4
//
//  Created by Devin Liu on 16/4/24.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

//for index_r:Int in 1...9{
//    for index_l:Int in 1...index_r{
//        print(" \(index_r)*\(index_l)=\(index_r * index_l)\t",terminator:"")
//        
//    }
//    print("")
//}
var t = [1,2,4,5]
t.removeAtIndex(0)
print(t)
