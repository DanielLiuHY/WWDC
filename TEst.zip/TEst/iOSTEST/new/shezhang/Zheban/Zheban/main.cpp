//
//  main.cpp
//  Zheban
//
//  Created by Devin Liu on 16/6/3.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

#include <iostream>

using namespace std;



//int ST[14]={0,2,4,6,9,10,13,15,16,19,25,30,40,50};
int search_Bin(int ST[],int key){
    int mid,low=1;
    int high=13;
    while(low<=high){
        mid=(low+high)/2;
        if(key==ST[mid]) return mid;
        else if(key<ST[mid]) high=mid-1;
        else low=mid+1;
    }
    return 0;
    
}


int main(){
    
    int ST[14]={0,2,4,6,9,10,13,15,16,19,25,30,40,50};
    int key;
    cout<<"key:\n";
    cin>>key;
    int i;
    i=search_Bin(ST,key);
    if(i==0)
        cout<<"not found!\n";
    else
        cout<<"found"<<ST[i]<<"in the"<<i+1<<"position";
    return 0;
    
}
