//
//  ViewController.m
//  Calculator
//
//  Created by Devin Liu on 16/6/10.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *input1; //第一个数
@property (weak, nonatomic) IBOutlet UITextField *input2; //第二个数
@property (weak, nonatomic) IBOutlet UIButton *plus;      //加
@property (weak, nonatomic) IBOutlet UIButton *minus;     //减
@property (weak, nonatomic) IBOutlet UIButton *multiply;  //乘
@property (weak, nonatomic) IBOutlet UIButton *divide;    //除
@property (weak, nonatomic) IBOutlet UILabel *result;     //结果
@property (weak, nonatomic) IBOutlet UIButton *exit;
@property (weak, nonatomic) IBOutlet UIButton *keyboard;
- (IBAction)myControl:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.input1.keyboardType = UIKeyboardTypeDecimalPad;
    self.input2.keyboardType = UIKeyboardTypeDecimalPad;
    [self.plus addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];
    [self.minus addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];
    [self.multiply addTarget:self action:@selector(calculate:) forControlEvents:
     UIControlEventTouchUpInside];
    [self.divide addTarget:self action:@selector(calculate:) forControlEvents:
     UIControlEventTouchUpInside];
    [self.exit addTarget:self action:@selector(exit1) forControlEvents:
     UIControlEventTouchUpInside];
   //[self.keyboard addTarget:self action:@selector(textFieldReturn:) forControlEvents:UIControlEventTouchUpInside];
}
-(void)calculate:(UIButton*)btn{
    NSString* strInput1 = self.input1.text;
    NSString* strInput2 = self.input2.text;
    if(![strInput1  isEqual: @""] && ![strInput2  isEqual: @""]){
    float fresult = 0;
    if([btn.titleLabel.text isEqualToString:@"plus"]){
        
        fresult = [strInput1 floatValue] + [strInput2 floatValue];
        self.result.text = [NSString stringWithFormat:@"%.02f",fresult];
    }
    else if ([btn.titleLabel.text isEqualToString:@"minus"]){
        fresult = [strInput1 floatValue] - [strInput2 floatValue];
        self.result.text = [NSString stringWithFormat:@"%.02f",fresult];
    }
    else if ([btn.titleLabel.text isEqualToString:@"multiply"]){
        fresult = [strInput1 floatValue] * [strInput2 floatValue];
        self.result.text = [NSString stringWithFormat:@"%.02f",fresult];
    }
    else if ([btn.titleLabel.text isEqualToString:@"divide"]){
        if([strInput2 floatValue] != 0){
        fresult = [strInput1 floatValue] / [strInput2 floatValue];
            self.result.text = [NSString stringWithFormat:@"%.02f",fresult];
        }
        else{
            
            self.result.text = [NSString stringWithFormat:@"Wrong Input"];
        }
    }
    }
    else{
        self.result.text = [NSString stringWithFormat:@"too few input"];
    }
}
-(void)exit1{
    exit(0);
}

- (IBAction)myControl:(id)sender {
    [_input1  resignFirstResponder];
    [_input2 resignFirstResponder];
}
@end
