//
//  ViewController.m
//  useUIView
//
//  Created by Devin Liu on 16/6/11.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *redView;
@property (weak, nonatomic) IBOutlet UIView *blueView;
@property (weak, nonatomic) IBOutlet UIView *greenView;
@property (weak, nonatomic) IBOutlet UIView *yellowView;
@property (weak, nonatomic) IBOutlet UIView *pinkView;



@end


@implementation ViewController
-(void)printDetailOfView:(UIView*)view{
    NSLog(@"The frame is %@",NSStringFromCGRect(self.view.frame));
    NSLog(@"The bounds is %@", NSStringFromCGRect(self.view.bounds));
    NSLog(@"The center is %@", NSStringFromCGPoint(self.view.center));
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self printDetailOfView:self.redView];
    [self printDetailOfView:self.blueView];
    [self printDetailOfView:self.greenView];
    [self printDetailOfView:self.yellowView];
    [self printDetailOfView:self.pinkView];

}

@end
