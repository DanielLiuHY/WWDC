//
//  main.c
//  shezhang
//
//  Created by Devin Liu on 16/6/2.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include<time.h>


int main(int argc, const char * argv[]) {
   
    time_t nowtime;
    struct tm* timeinfo;
    time(&nowtime);
    timeinfo = localtime(&nowtime);
    
    
    
    return 0;
}
