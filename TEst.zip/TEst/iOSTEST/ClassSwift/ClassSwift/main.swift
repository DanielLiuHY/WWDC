//
//  main.swift
//  ClassSwift
//
//  Created by Devin Liu on 16/5/7.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

import Foundation


func randomString(len:Int)->String{
    var string=""
    
    for _ in 0..<len{
        string.append(UnicodeScalar((65+arc4random()%26)))
    }
    return string
}
var list = [girlFriend]()
for i:Int in 0...999{
    var s_i = girlFriend()
    s_i.age = arc4random_uniform(15)+15
    s_i.name = randomString(Int(1+arc4random()%10))
    list.append(s_i)
    
}
print(list)
list[5].letsdate(hangOut.film)
 