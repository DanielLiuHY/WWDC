//
//  girlFriend.swift
//  ClassSwift
//
//  Created by Devin Liu on 16/5/7.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

import Foundation

public enum hangOut:String{
    case film = "看电影"
    case dinner = "吃晚饭"
    case park = "去公园"
    case rest = "在家休息"
}

public class girlFriend:NSObject{
    private var _age:UInt32!
    private var _name:String!
    private var _date:hangOut = hangOut.rest
    
    public var age:UInt32{
        get{
            return _age
        }
        set{
            _age=newValue
        }
    }
    
    public var name:String{
        get{
            return _name
        }
        set{
            _name=newValue
        }
    }
    public var date:hangOut{
        get{
            return _date
        }
        set{
            _date=newValue
        }
    }
    
    public func letsdate(b:hangOut){
        _date = b
        print("\(_name),我们一起\(_date.rawValue)吧！")
    }
    override public var description: String{
        get{
            return "name:\(name),age:\(age),状态:\(date)"
        }
    }
    
}
