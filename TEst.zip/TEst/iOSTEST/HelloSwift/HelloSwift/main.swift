//
//  main.swift
//  HelloSwift
//
//  Created by Devin Liu on 16/4/21.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

import Foundation

struct student {
    var name:String
    var mathScore:Double
    var engScore:Double
    func average()->Double {
        return(self.engScore+self.mathScore)/2
    }
}

var newStudentlist = [student]()
    func min (e:[student])->Int {
    let num:Int = e.count
    var n:Int = 0
    var largestNum:Double = 100
    for i:Int in 0...num-1 {
        if(e[i].average()<largestNum) {
            largestNum = e[i].average()
            n = i
        }
    
    }
        newStudentlist.append(e[n])
        return n
    
}

var studentList=[student]()
var liu = student(name:"Liuyi",mathScore:89.0,engScore: 100.0)
var li  = student(name:"Lier",mathScore:79.7,engScore:88.5)
var wang = student(name:"Wangsan",mathScore:77,engScore:37)
var zhao = student(name:"Zhaosi",mathScore:46,engScore:89)
var qian = student(name:"Qianwu",mathScore:90,engScore:75)
var sun = student(name:"Sunliu",mathScore:83,engScore:41)
var zhou = student(name:"Zhouqi",mathScore:21,engScore:12)
var wu = student(name:"Wuba",mathScore:41,engScore:51)
var zheng = student(name:"Zhengjiu",mathScore:55,engScore:72)
var wan = student(name:"Wanshi",mathScore:44,engScore:99.5)
studentList.append(liu)
studentList.append(li)
studentList.append(wang)
studentList.append(zhao)
studentList.append(qian)
studentList.append(sun)
studentList.append(zhou)
studentList.append(wu)
studentList.append(zheng)
studentList.append(wan)

for Index in 0...studentList.count-1 {
    
    studentList.removeAtIndex(min(studentList))
}



//newStudentlist.sortInPlace({$0.Average()<$1.Average()})
for i in 0...newStudentlist.count-1 {
    print("\(newStudentlist[i].name)的平均分是\(newStudentlist[i].average()), 数学成绩: \(newStudentlist[i].mathScore), 英语成绩:\(newStudentlist[i].engScore)")
    }

