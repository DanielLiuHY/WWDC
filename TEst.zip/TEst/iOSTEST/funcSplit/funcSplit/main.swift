//
//  main.swift
//  funcSplit
//
//  Created by Devin Liu on 16/5/8.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

import Foundation

var a = "Hello&jikexueyuan&Hello"
print(a.split("lo"))
print (a.split("&"))
print (a.split("jikexueyuan"))