//
//  stringSplit.swift
//  funcSplit
//
//  Created by Devin Liu on 16/5/10.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

import Foundation
extension String{
    mutating func split(seperator:String) -> [String] {
        let len = self.characters.count
        let all = self.characters
        let tar = seperator.characters
        let sublen = seperator.characters.count
        var temp = ""
        var la = self
        var arr = [String]()
        var c = 0
        for var i in 0..<len - sublen {
            c = 0
            if tar[tar.startIndex.advancedBy(0)] == all[all.startIndex.advancedBy(i)] {
                c = 0
                for  m in 0..<sublen {
                    if tar[tar.startIndex.advancedBy(m)] != all[all.startIndex.advancedBy(m+i)] {
                        c = 0
                        break
                    }
                    else {
                        c=c+1
                    }
                    
                    if c == sublen {
                        c = 0
                        let hh = abs(la.characters.count - self.characters.count)
                        let startIndex = la.startIndex.advancedBy(0)
                        let endIndex  = la.startIndex.advancedBy(i-hh-1)
                        let secIndex = la.startIndex.advancedBy(i-hh+sublen-1)
                        let r  = startIndex...secIndex
                        let rr = startIndex ... endIndex
                        temp = la.substringWithRange(rr)
                        arr.append(temp)
                        la.removeRange(r)
                        temp = ""
                        i = 0
                        
                    }
                    
                }
            }
            
        }
        if la != "" {
            arr.append(la)
        }
        return arr
    }
    
}