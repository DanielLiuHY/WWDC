//
//  main.swift
//  HelloSwift
//
//  Created by Devin Liu on 16/4/19.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

import Foundation

print("Hello, World!")

