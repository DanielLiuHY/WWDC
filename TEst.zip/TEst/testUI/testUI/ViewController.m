//
//  ViewController.m
//  testUI
//
//  Created by Devin Liu on 16/6/13.
//  Copyright © 2016年 DanielLiu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UISlider *myslider;
@property (weak, nonatomic) IBOutlet UISwitch *myswitch;
@property (weak, nonatomic) IBOutlet UIImageView *image1;
@property (weak, nonatomic) IBOutlet UILabel *sliderValue;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.myslider addTarget:self action:@selector(myslider1) forControlEvents:UIControlEventValueChanged];
    [self.myswitch addTarget:self action:@selector(myswitch1) forControlEvents:UIControlEventTouchUpInside];
    self.sliderValue.text =[ NSString stringWithFormat:@"1.00"];
    
    UIImageView* image = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 150, 150)];
    [image setImage: [UIImage imageNamed:@"1.png" ]];
    
    image.backgroundColor = [UIColor brownColor];
    
    image.contentMode =  UIViewContentModeCenter;
    
    [self.view addSubview:image];
}

-(void)myslider1{
    self.image1.alpha = 0.010101 * (self.myslider.value - 1);
    self.sliderValue.text =[NSString stringWithFormat:@"%f", self.myslider.value ];
}

-(void)myswitch1{
    if(self.myswitch.isOn){
        self.myslider.enabled = YES;
    }
    else{
        self.myslider.enabled = NO;
    }
}

@end
